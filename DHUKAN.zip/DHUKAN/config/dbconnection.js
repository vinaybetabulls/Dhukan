var mysql=require('mysql');
 var connection=mysql.createPool({
host:'192.169.243.70',
 user:'vmcoin_dhukan',
 password:'@Dhukan123@',
 database:'vmcoin_dhukan'
 
});
 module.exports=connection;