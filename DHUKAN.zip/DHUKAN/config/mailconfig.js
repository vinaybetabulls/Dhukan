module.exports={
    forgotMailUsername:'tejasree406@gmail.com',
    forgotMailPassword:'memory@123',

     MOBILE_API_KEY : '1ba0b127',
     MOBILE_SECRETE_KEY:'f6867024178692dd',
     NEXMO_NUMBER:919951502790,
    ACCOUNT_SID:'AC1c9bbe93ad6182b8c5d14197b605371c',
    AUTH_TOKEN:'66f97a657372915b17c1e338859f0a05' 
}