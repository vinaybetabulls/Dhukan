module.exports={
     "path":"http://versatilemobitech.co.in/DHUKAN/images/",
     "secret":"admin-user-secret",
     "tokenLife": 900,
     "refreshTokenLife": 86400


}