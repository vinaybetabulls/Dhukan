//reference of dbconnection.js
var db = require('../config/dbconnection'); 
var categories = {
    //All categories list
    getAllCategories: function (callback) {
        return db.query("SELECT `id`, `name`, `description`, `is_active`,`parent_cat_id`,`pic` FROM `categories`", callback);
    },
    getCategoryById: function (id, callback) {
        return db.query("SELECT `id`, `name`, `description`, `is_active` FROM `categories` where id=?", [id], callback);
    },
    getCategoryProducts:function(categoryid, callback){
        return db.query("SELECT `id`, `title`, `description`, `category_id`, `actual_price`, `is_active`, `brand_id`,  `product_image`, `thumb_image1` FROM `products` where category_id=?", [categoryid], callback);
    }
};
module.exports = categories;