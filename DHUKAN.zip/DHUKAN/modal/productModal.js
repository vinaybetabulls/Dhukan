//reference of dbconnection.js
var db = require('../config/dbconnection'); 
var products = {
    //All categories list
    getAllProducts: function (callback) {
        return db.query("SELECT `id`, `title`, `description`, `category_id`, `actual_price`, `is_active`, `brand_id`,  `product_image`, `thumb_image1` FROM `products`", callback);
    },
    getProductById: function (id, callback) {
        return db.query("SELECT `id`, `title`, `description`, `category_id`, `actual_price`, `is_active`, `brand_id`,  `product_image`, `thumb_image1` FROM `products` where id=?", [id], callback);
    }
};
module.exports = products;