//reference of dbconnection.js
var db = require('../config/dbconnection'); 
var banners = {
    //All categories list
    getAllbanners: function (callback) {
        return db.query("SELECT `id`, `name`, `pic`, `pic_web`, `type` FROM `banners` ", callback);
    }
};
module.exports = banners;