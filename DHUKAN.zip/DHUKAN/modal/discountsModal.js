//reference of dbconnection.js
var db = require('../config/dbconnection'); 
var discounts = {
    //All categories list
    getAlldiscounts: function (callback) {
        return db.query("SELECT `id`, `discount_type_id`, `currency_id`, `discount_var_id`, `value` FROM `discounts` ", callback);
    }
};
module.exports = discounts;