//reference of dbconnection.js
var db = require('../config/dbconnection'); 
var orderItems = {
    //All categories list
    getPopularProducts: function (limit,callback) {
        if(limit === undefined || limit === '' || limit === null){
            limit = 5;
        }
        return db.query("SELECT oi.product_id,sum(oi.quantity) as quantity,p.title as name,p.description,b.name as brand_name,c.name as category_name,p.category_id FROM order_items oi left join products p on p.id = oi.product_id left join brands b on b.id = p.brand_id left join categories c on c.id = p.category_id group by oi.product_id order by oi.created_on limit "+limit+" ", callback);
    }
};
module.exports = orderItems;