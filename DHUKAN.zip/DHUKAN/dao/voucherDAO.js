var db = require('../config/dbconnection'); 

var voucher ={
    findVoucherCode:function(vouchercode,amount,callback){
        
        db.query("SELECT * FROM `vouchers` where  voucher_code=? and minimum_value<=? and available_count>0" , [vouchercode,amount]
        ,callback);
       
    },
    saveDiscountAmount : function(result,callback){
        
            voucher_id= result.id,
            
            bill_amount= result.bill_amount ,
           
            discount_amount=  result.discount_amount,
           
          
    
        
        db.query("INSERT INTO voucher_user(voucher_id,bill_amount,discount_amount) VALUES("+voucher_id+","+bill_amount+","+discount_amount+")", callback)
     
        
    },
    changeDiscount:function(voucher,cupon,callback){
        
     db.query("UPDATE vouchers SET available_count="+voucher+" WHERE id="+cupon+"",callback)

    }
}

module.exports = voucher