const common = require('../common');
var db = require('../config/dbconnection'); 
var subcategories = {
    insertsub:function(data,callback){
        console.log(data)
        //if(data.image_path!==undefined){
       //console.log("INSERT INTO categories (name,parent_cat_id) values ('"+data.name+"',"+data.categiryid+" )")
       console.log("INSERT INTO categories (name,parent_cat_id,pic,description) values ('"+data.name+"',"+data.categiryid+",'"+data.image_path+"','"+data.description+"' )")
        db.query("INSERT INTO categories (name,parent_cat_id,pic,description) values ('"+data.name+"',"+data.categiryid+",'"+data.image_path+"','"+data.description+"' )"
        ,callback);
        
    },
    getdata:function(callback){
        //console.log("hii")
        db.query("SELECT c1.id as main_cat_id, c1.name as main_cat,c2.id as sub_cat_id,c2.name as sub_cat,c2.pic as image from categories c1, categories c2 WHERE c1.id = c2.parent_cat_id",callback)
    },
    delete:function(data,callback)
   {
    return db.query("delete from categories  where id="+data.sub_cat_id+"",callback)
   },
   update:function(data,callback){
         //console.log(data)
       if(data.image_path!==undefined){
            console.log(data.image_path)
        //console.log("UPDATE categories SET parent_cat_id="+data.main_cat_id+", name='"+data.sub_cat+"',pic='"+data.image_path+"',description='"+data.description+"' WHERE id="+data.sub_cat_id+" ")
       
    return db.query("UPDATE categories SET parent_cat_id="+data.main_cat_id+", name='"+data.sub_cat+"',pic='"+data.image_path+"',description='"+data.description+"' WHERE id="+data.sub_cat_id+" ",callback)
       }else{
            console.log("hiii teja")
            //console.log("UPDATE categories SET parent_cat_id="+data.main_cat_id+", name='"+data.sub_cat+"',description='"+data.description+"' WHERE id="+data.sub_cat_id+" ")
        return db.query("UPDATE categories SET parent_cat_id="+data.main_cat_id+", name='"+data.sub_cat+"',description='"+data.description+"' WHERE id="+data.sub_cat_id+" ",callback)
       }
   },
   getcategoryById:function(data,callback){
        //console.log(data)
        //console.log("select * from categories where id="+data.sub_cat_id+"")
    return db.query("select * from categories where id="+data.sub_cat_id+"",callback)
   }
}
module.exports=subcategories