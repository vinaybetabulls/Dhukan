//reference of dbconnection.js
var db = require('../config/dbconnection'); 
var categories = {
    //All categories list
    getUserById:function(callback){

    },
    getAllCategories: function (callback) {
        
        return db.query("SELECT `id`, `name`, `description`, `is_active`,`parent_cat_id`,`pic` FROM `categories`", callback);
    },
    getCategoryById: function (id, callback) {
        var que = "SELECT * FROM `categories` where id= "+id+" or parent_cat_id = "+id+" ";
        return db.query(que, callback);
    },
    getCategoryProducts:function(categoryid, callback){
        return db.query("SELECT `id`, `title`, `description`, `category_id`, `actual_price`, `is_active`, `brand_id`,  `product_image`, `thumb_image1` FROM `products` where category_id in ("+categoryid+") ", callback);
    },
    getAllCategoriesWithlimit(start,limit,callback) {                                                                                                                                                                                                                                               
        return db.query("SELECT `id`, `name`, `description`, `is_active`,`parent_cat_id`,`pic` FROM `categories` limit "+start+","+limit+" ", callback);
    },
    deleteCategires(id,callback){
        //console.log(id)
        return db.query("DELETE FROM categories WHERE id="+id+"", callback);
    },
    upadteCategires(data,callback){
        if  (data.image !==undefined){
           // console.log("image")
        //console.log(data)
     return db.query("UPDATE categories SET name ='"+data.name+"',pic='"+data.image_path+"',description='"+data.description+"' WHERE id="+data.id+" ",callback);
        }else{
            return db.query("UPDATE categories SET name ='"+data.name+"',description='"+data.description+"' WHERE id="+data.id+" ",callback);
        }
    },
    insertcatagiries(data,callback){
         var name=data.name
         return db.query("INSERT INTO categories(name,pic,description) VALUES('"+name+"','"+data.image_path+"','"+data.description+"')",callback);
    },
    getallacategaries(callback){
        return db.query("select * from categories  WHERE  parent_cat_id IS NULL",callback)
    },
    getcategoryById(data,callback){
        return db.query("select * from categories  WHERE id='"+ data.id+"'",callback)
    },
    categoryName(data,callback){
        return db.query("select * from categories  WHERE name='"+ data.name+"'",callback)
    }
};
module.exports = categories;
