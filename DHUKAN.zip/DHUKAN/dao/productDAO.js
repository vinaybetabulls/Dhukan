//reference of dbconnection.js
var db = require('../config/dbconnection');
const common = require('../common');
var productsQuery = "SELECT p.id, p.title,  p.category_id, p.category2_id, p.category3_id, p.is_active,p.brand_id,  p.thumb_image1,b.name as brand_name, c.name as category1,c2.name as category2,c3.name as category3,f4.question, f4.answer,t5.data as terms_and_conditions FROM products p left join brands b on b.id = p.brand_id left join categories c on c.id = p.category_id left join categories c2 on c2.id = p.category2_id left join categories c3 on c3.id = p.category3_id LEFT JOIN faq f4 ON p.id = f4.product_id LEFT JOIN terms_and_conditions t5 on p.id = t5.product_id";
var products = {
    //All categories listku
    getAllProducts: function (limit, callback) {
        var que = productsQuery + " ";
        if (limit != '') { 
            que += " limit " + limit;
        }
        return db.query(que, callback);
    },
    getAllProductsWithLimit: function (start, limit, callback) {
        var que = productsQuery + " ";
        if (limit != '') {
            que += " limit " + start + ", " + limit;
        }
        return db.query(que, callback);
    },
    getProductById: function (reqObj, callback) {
        console.log("helllo dhukan", reqObj)
        let product_id = reqObj.product_id || reqObj.id;
        console.log("product_id...", product_id)
        return db.query(productsQuery + " where p.id in (" + product_id + ") ", callback);
    },
    getproducts: function (callback) {
        //console.log("SELECT categories.name,products.*,products.id as _id FROM products LEFT JOIN categories ON products.category_id=categories.id")
        // return db.query("SELECT categories.name FROM products, categories WHERE products.category_id= categories.id",callback)
        // return db.query("SELECT categories.name,products.*,products.id as _id FROM products LEFT JOIN categories ON products.category_id=categories.id",
        // callback)
        return db.query("SELECT p1.*,c1.name as main_cat,c2.name as sub_cat FROM products as p1 INNER JOIN categories as c1 ON p1.category_id = c1.id  LEFT JOIN categories as c2 on c2.id = p1.category2_id", callback)
        //return db.query("select *  from  products",callback) 
    },
    deleteproducts: function (data, callback) {

        return db.query("delete from products where id=" + data.id + "", callback)
    },
    deleteproductimage: function (data, callback) {
        return db.query("DELETE products,product_images FROM products JOIN product_images ON products.id=product_images.product_id WHERE products.id = " + data.id + "", callback)
    },
    updateproduct: function (data, callback) {
        //    var category_id = data.category_id || '';
        //console.log(data.id)
        //console.log(data.image_path)
        //console.log("UPDATE products SET category_id=" + data.category_id + " title='" + data.title + "'  WHERE id=" + data.id + " ")
       // return db.query("UPDATE products SET category_id=" + data.category_id + ",title='" + data.title + "' WHERE id=" + data.id + " ", callback);
        return db.query(`UPDATE products SET category_id=${data.category_id},category2_id=${data.category2_id},title='${data.title}',brand_name='${data.brand_name}',brand_id=${data.brand_id}`,callback)
    },
    updateTerms :(data,callback)=>{
        return db.query(`UPDATE terms_and_conditions SET data=${data.data} WHERE sku_id=${data.sku_id}`,callback)
    },
    updateFAQ : (data,callback)=>{
        return db.query(`UPDATE faq SET question = '${data.question}', answer='${data.answer}' WHERE sku_id=${data.sku_id}`,callback)
    },
    insertpoduct: function (data, callback) {
        //console.log(data.image_path)
        //console.log("INSERT INTO products(title,category_id,category2_id,description,manufacture_name) VALUES('" + data.title + "' ," + data.category_id + ",'" + data.subcategory_id + "','" + data.description + "','" + data.manufacture_name + "')")
        let query = `INSERT INTO products (title,category_id,category2_id,brand_id,brand_name) VALUES ('${data.title}',${data.category_id},${data.subcategory_id},${data.brand_id},'${data.brand_name}')`
        return db.query(query, callback);


    },
    insertImages: function (data, callback) {
        return db.query("INSERT INTO product_images(product_id,product_image)VALUES(" + data.product_id + ",'" + data.image_path + "')", callback)
    },
    insertfaq: function (data, callback) {
        return db.query("INSERT INTO faq(product_id,question,answer)VALUES(" + data.product_id + ",'" + data.question + "','" + data.answer + "')", callback)
    },
    insertTermsAndConditions: (data, callback) => {
        return db.query(`INSERT INTO terms_and_conditions(product_id,data) VALUES(${data.product_id},'${data.terms}')`, callback)
    },
    getProductImages: function (id, callback) {
        console.log(`SELECT * FROM product_images WHERE product_id=${id}`)
        return db.query(`SELECT * FROM product_images WHERE product_id=${id}`, callback)
    },
    getAllProductImages: function (product_id, callback) {
        return db.query(`SELECT * FROM product_images WHERE product_id IN(${product_id})`, callback)

    },
    updateProductImageById: function (data, callback) {
        //console.log(data.image_path+"......"+data.id);
        //console.log(data)
        return db.query(`UPDATE product_images SET product_image='${data.image_path}' WHERE id= ${data.id}`, callback)
    },
    getsubdata: function (data, callback) {

        // console.log("select * from categories where parent_cat_id="+data.cat_id+"")
        return db.query("select *,name as sub_cat from categories where parent_cat_id=" + data.cat_id + "", callback)
    },
    getSubCategoryProducts: function (reqObj, callback) {
        var sub_category_id = common.gNUE(reqObj.sub_category_id);
        var limit = common.gNUE(reqObj.limit);
        var limit_from = common.gNUE(reqObj.limit_from);
        var sort = common.gNUE(reqObj.sort);
        var sortType = common.gNUE(reqObj.sortType); // popularity, price low-high/high-low, alphabetical order
        var search_string = common.gNUE(reqObj.search_string);

        var limitQue = "";
        var whereCond = " ";
        if (sub_category_id != '') {
            whereCond = " and p.category2_id in (" + sub_category_id + ") and c2.parent_cat_id != '' ";
        }
        if (search_string != '') {
            whereCond += " and ( p.title like '%" + search_string + "%' or c.name like '%" + search_string + "%' or c2.name like '%" + search_string + "%' ) ";
        }
        if (sortType == 'popularity') {
            var query = "SELECT oi.product_id,sum(oi.quantity) as quantity,p.*,b.name as brand_name,c.name as category_name,c2.name as sub_category_name FROM order_items oi ";
            query += " left join products p on p.id = oi.product_id ";
            query += " left join brands b on b.id = p.brand_id ";
            query += " left join categories c on c.id = p.category_id ";
            query += " left join categories c2 on c2.id = p.category2_id ";
            query += " where p.is_deleted = 0 " + whereCond;
            query += " group by oi.product_id ";
            query += " order by quantity " + sort + " ";
        } else if (sortType == 'plh' || sortType == 'phl') {
            // price low to high or high to low
            var query = " select ps.skid,p.* from product_sku ps ";
            query += " left join products p on p.id = ps.product_id ";
            query += " left join categories c on c.id = p.category_id ";
            query += " left join categories c2 on c2.id = p.category2_id ";
            query += " where p.is_deleted = 0 " + whereCond;
            query += " order by ps.actual_price ";
            if (sortType == 'plh') {
                query += " asc ";
            } else if (sortType == 'phl') {
                query += " desc ";
            }
        } else {
            var query = "SELECT p.*,(actual_price - offer_price) as discount_price,c.name as category_name,c2.name as sub_category_name FROM products p ";
            query += " left join categories c on c.id = p.category_id ";
            query += " left join categories c2 on c2.id = p.category2_id ";
            query += " where p.is_deleted = 0 " + whereCond;

            if (sortType == 'alphabetical') {
                query += " order by p.title asc ";
            } else if (sortType == 'percenthl') {
                query += " order by p.selling_price desc ";
            } else if (sortType == 'ruplh' || sortType == 'ruphl') {
                // rupee saving high to low / low to high
                query += " order by discount_price  ";
                if (sortType == 'ruplh') {
                    query += " asc ";
                } else if (sortType == 'ruphl') {
                    query += " desc ";
                }
            } else if (sort != '') {
                query += " order by p.id " + sort + " ";
            }
        }

        if (limit != '' && limit_from != '') {
            limitQue = " limit  " + limit_from + "," + limit;
        }
        query = query + limitQue;
        return db.query(query, callback);
    },

    getRefineProductsBySubcategoryId: function (reqObj, callback) {
        var sub_category_id = common.gNUE(reqObj.sub_category_id);
        var limit = common.gNUE(reqObj.limit);
        var limit_from = common.gNUE(reqObj.limit_from);
        var sort = common.gNUE(reqObj.sort);
        var brand_id = common.gNUE(reqObj.brand_id);
        var price_from = common.gNUE(reqObj.price_from);
        var price_to = common.gNUE(reqObj.price_to);
        var discount = common.gNUE(reqObj.discount);
        var search_string = common.gNUE(reqObj.search_string);

        var discountEle = ""; var discountWhere = "";
        if (discount != '') {
            discountEle = " ,((ps.actual_price - ps.offer_price)/ps.actual_price) * 100 as discount_percentage";
            discountWhere = " and discount_percentage = '" + discount + "' ";
        }

        var limitQue = "";
        var whereCond = " ";
        if (sub_category_id != '') {
            whereCond = " and p.category2_id in (" + sub_category_id + ") and c2.parent_cat_id != '' ";
        }
        if (search_string != '') {
            whereCond += " and ( p.title like '%" + search_string + "%' or c.name like '%" + search_string + "%' or c2.name like '%" + search_string + "%' ) ";
        }
        var query = " select ps.skid,p.*" + discountEle + " from product_sku ps ";
        query += " left join products p on p.id = ps.product_id ";
        query += " left join categories c on c.id = p.category_id ";
        query += " left join categories c2 on c2.id = p.category2_id ";
        query += " where p.is_deleted = 0 " + whereCond + discountWhere;

        if (brand_id != '') {
            query += " and p.brand_id in (" + brand_id + ") ";
        }

        if (price_from != '' && price_to != '') {
            query += " and ps.actual_price <= " + price_from + " and ps.actual_price >= " + price_to + " ";
        }

        query += " order by ps.actual_price " + sort;
        if (limit != '' && limit_from != '') {
            limitQue = " limit  " + limit_from + "," + limit;
        }
        query = query + limitQue;
        return db.query(query, callback);
    },
    getIndividualProductById: (productId, callback) => {
        return db.query(`SELECT title,description FROM products where id='${productId}'`, callback)
    },
    getIndividualSKU: (skuId, callback) => {
        return db.query(`SELECT actual_price,offer_price,selling_price FROM product_sku WHERE skid='${skuId}'`, callback)
    },
    InsertSKU: (sku, callback) => {
        //  console.log(`INSERT INTO product_sku (product_id,size,mrp,actual_price,offer_price,image,stock,selling_price)values(${sku.product_id},${sku.size},${sku.mrp},${sku.mrp},${sku.offer},${sku.image_path},${sku.stock},${sku.sellingPrice})`)
        return db.query(`INSERT INTO product_sku (product_id,size,mrp,actual_price,offer_price,image,stock,selling_price)values(${sku.product_id},'${sku.size}',${sku.mrp},${sku.mrp},${sku.offer},'${sku.image_path}',${sku.stock},${sku.sellingPrice})`, callback)

    },
    insertSKUImages: (skuId, dbPath, callback) => {
        return db.query(`INSERT INTO product_sku_images (sku_id,sku_image) VALUES (${skuId},'${dbPath}')`, callback)
    },
    getQuantityBySkuId: (skid, product_id, user_id, session_id, callback) => {
        //console.log("sessionId..",session_id)
        //console.log("userId..",user_id)
        //console.log(skid,product_id,user_id,session_id)
        // console.log("select * form cart_orders where product_sku_id="+skid+" AND product_id="+product_id+" AND(session_id="+session_id+" OR user_id="+user_id+")")
        return db.query(`select * from cart_orders where (product_sku_id=${skid} AND product_id=${product_id}) AND (session_id='${session_id}' OR user_id='${+user_id}')`, callback)

    },
    getpayment: (callback) => {
        return db.query("select * from payment_option", callback)

    },
    getproductskubyid: (data, callback) => {
        //console.log("SELECT * FROM product_sku where product_id="+data.id+"")
        return db.query("SELECT * FROM product_sku where product_id=" + data.id + "", callback)
    },
    getskuimagesdata: (data, callback) => {
        //console.log("SELECT * FROM product_sku_images where sku_id="+data+"")
        return db.query("SELECT * FROM product_sku_images where sku_id=" + data + "", callback)
    },
    getProductsCount: (callback)=>{
        return db.query(`SELECT count(*) as numRows FROM products`,callback);
    },
    getProducts: (limit,callback)=>{
        return db.query('SELECT * FROM products  LIMIT ' + limit,callback)
    }
};

module.exports = products;

