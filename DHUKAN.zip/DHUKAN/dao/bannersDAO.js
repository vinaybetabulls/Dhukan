//reference of dbconnection.js
var db = require('../config/dbconnection'); 
var banners = {
    //All banners list
    /**
     * 06-09-2018 6:24
     * target is where to navigate 
     * wheather product list or product details or some offer scree.
     * 
     */

    getAllbanners: function (callback) {
        return db.query("SELECT `id`, `name`, `pic`, `pic_web`, `type`,target,sequence,banner_position FROM `banners` order by id desc", callback);
    },
    getAllbannersWithLimit: function (start,limit,callback) {
        var que = "SELECT `id`, `name`, `pic`, `pic_web`, `type`,target,sequence,banner_position FROM `banners` order by id desc limit "+start+','+limit+" ";
        return db.query(que, callback);
    },
    insertbaneers:function(data,callback){
        return db.query("INSERT INTO banners(banner_position) VALUES('"+data.title+"')",callback);
    },
    insertbanerimages:function(data,callback){
        return db.query("INSERT INTO banner_images(mobile_bannerimage,website_bannerimage,banner_id,name,type,target) VALUES('"+data.mobileimage_path+"','"+data.website_path+"','"+data.banner_id+"','"+data.name+"','"+data.type+"','"+data.target+"')",callback);

    },
    delte_banner:function(data,callback){
        return db.query("DELETE banners,banner_images  FROM banners JOIN banner_images ON banners.id=banner_images.banner_id WHERE banners.id = "+data.id+"",callback)
    },
    deleteindivisuvalbaneer:function(data,callback){
         //console.log("delete from banner_images where id="+data.id+"")
        return db.query("delete from banner_images where image_id="+data.id+"",callback)
    },
    getBannerByTitle : (title,callback)=>{
        return db.query(`SELECT * FROM banners WHERE banner_position='${title}'`,callback);
    },
    getAllbannersList:(callback)=>{
        return db.query(`SELECT * FROM banners`,callback)
    },
    getAllbannersImages : (callback)=>{
        return db.query(`SELECT * FROM banner_images`,callback);
    },
    getBannerImageById : (id,callback)=>{
        //console.log(`SELECT * FROM banner_images WHERE image_id = ${id}`)
        return db.query(`SELECT * FROM banner_images WHERE image_id = ${id}`,callback)
    },
    updateBannerImageById : (data,callback)=>{
        //console.log("data...",data)
        return db.query(`UPDATE banner_images SET website_bannerimage = '${data.website_bannerimage}', mobile_bannerimage = '${data.mobile_bannerimage}',type = '${data.type}',name='${data.name}' WHERE image_id=${data.id}`,callback)
    },
    getbannerpostion:(callback)=>{
        return db.query("select banner_position from banners",callback)
  
    }
    
  

};
module.exports = banners;