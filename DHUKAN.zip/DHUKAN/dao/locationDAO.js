var db = require('../config/dbconnection'); //reference of dbconnection.js
const common = require('../common');
var location={
    getCountry : (country,callback)=>{
        return db.query(`SELECT * FROM country WHERE name='${country.toLowerCase()}'`,callback)
    },
    getState:(state,callback)=>{ 
        return db.query(`SELECT * FROM state WHERE state='${(state.state).toLowerCase()}' AND country_id='${state.country}'`,callback)
    },
    getCity : (city,callback)=>{
        return db.query(`SELECT * FROM locations WHERE location_name='${(city.city).toLowerCase()}' AND state_id='${(city.state).toLowerCase()}'`,callback)
    },
    insertCountry:(data,callback)=>{
         return db.query(`INSERT INTO country(name ) VALUES ( '${(data.country)}')`,callback)

    },
    insertState:(data,callback)=>{
        return  db.query(`INSERT INTO state(state,country_id) VALUES ('${(data.state)}',${(data.countryId)})`,callback)

    },
    insertCity:(data,callback)=>{
        return db.query(`INSERT INTO locations( country_id, location_name,state_id) VALUES (${(data.countryId)},'${(data.city)}',${data.stateId})`,callback)

    },
    getcountrys:(callback)=>{
        //console.log("hello teja")
        return db.query("select * from country",callback)
    },
    getstatus:(callback)=>{
        return db.query("select * from state where country_id="+data.country_id+"",callback)
        
    },
    getcity:(data,callback)=>{
        return db.query("select * from locations where state_id="+data.state_id+"",callback)
    }
}
module.exports = location ;