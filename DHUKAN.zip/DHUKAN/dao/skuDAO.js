//reference of dbconnection.js
var db = require('../config/dbconnection');
// `skid`, `product_id`, `sku`, `size`, `size_measuring_unit`, `box_color`, `filter_color`, `actual_price`, `min_quantity`, `stock`, `selling_price`, `status`,tax,realization,mrp
var sku = {
    getProductSkuByProductId: function (product_id, callback) {
        //console.log("teja",product_id)
        return db.query("SELECT * FROM `product_sku` where product_id in (" + product_id + ")", callback);
    },
    getProductSkuByProductIdAndSkuId: function (reqParamsObj, callback) {
        var product_id = reqParamsObj.product_id;
        console.log("dashbord service",product_id)
        var sku_ids = reqParamsObj.sku_ids;
        console.log("sku_ids..", sku_ids)
        var que = "SELECT * FROM `product_sku` where skid in (" + sku_ids + ") ";
        return db.query(que, callback);
    },
    getSKUImages: (sku, callback) => {
        return db.query(`SELECT * FROM product_sku_images WHERE sku_id in(${sku})`, callback)
    },
    getbyproductsbyidproductsid: function (reqParamsObj, callback) {
        var product_id = reqParamsObj.product_id;
        console.log(product_id)
        var sku_ids = reqParamsObj.sku_ids;
        console.log("sku_ids..", sku_ids)
        var que = "SELECT * FROM `product_sku` ps join product_sku_images p1 on p1.sku_id=ps.skid where ps.skid in (" + sku_ids + ") ";
        return db.query(que, callback);

    },
    updateProductSKU: (sku_data, callback) => {
        return db.query(`UPDATE product_sku SET size='${sku_data.size}',size_measuring_unit='${sku_data.size_measuring_unit}',actual_price=${sku_data.actual_price},mrp=${sku_data.mrp},min_quantity=${sku_data.min_quantity},stock=${sku_data.stock},selling_price=${sku_data.selling_price},offer_price=${sku_data.offer_price},status=${sku_data.status},image='${sku_data.image_path}' WHERE skid=${sku_data.skid}`, callback)
    },
    
    saveProductSKU : (skuData,product_id,callback)=>{
        console.log(skuData.quality)
        if(skuData.quality==undefined){
            skuData.quality=''
        }
        if(skuData.quantity==undefined){
            skuData.quantity = skuData.min_quantity;
        }
        if(skuData.sellingPrice==undefined){
            skuData.sellingPrice = skuData.selling_price;
        }
        if(skuData.offer==undefined){
            skuData.offer = skuData.offer_price;
        }
        let query = `INSERT INTO product_sku (product_id,size,actual_price,mrp,min_quantity,stock,selling_price,offer_price,image,express_delivery,normal_delivery,description,specification,country,city,state,area,quality_image) VALUES (${product_id},'${skuData.size}',${skuData.mrp},${skuData.mrp},${skuData.quantity},${skuData.stock},${skuData.sellingPrice},${skuData.offer},'${skuData.image}',${skuData.express_delivery},${skuData.normal_delivery},'${skuData.Description}','${skuData.specification}','${skuData.country}','${skuData.city}','${skuData.state}','${skuData.area}','${skuData.quality}')`
        return db.query(query,callback);
    },
    saveProductSKUImages : (data,callback)=>{
        //console.log(data)
        let query = `INSERT INTO product_sku_images(sku_id,product_id,sku_image) VALUES (${data.sku_id},${data.product_id},'${data.image_path}')`;
        return db.query(query,callback);
    },
    inserfaq:(data,callback)=>{
        console.log(data)
        let query=`INSERT INTO faq(question,answer,product_id,sku_id)VALUES('${data.faq}','${data.answer}',${data.product_id},${data.sku_id})`;
        return db.query(query,callback);
    },
    insertTermsAndConditions:(data,callback)=>{
        let query=`INSERT INTO terms_and_conditions(data,product_id,sku_id)VALUES('${data.terms}',${data.product_id},${data.sku_id})`
         return db.query(query,callback);

    },
    getimages:(data,callback)=>{
         //console.log("teja",data)
        let quey = "SELECT * FROM `product_sku_images` where sku_id in (" +data +")"
        
         return db.query(quey,callback);
    },
    gettermesandcontions:(data,callback)=>{
        let quey = "SELECT * FROM `terms_and_conditions` where sku_id in (" +data +")"
        
        return db.query(quey,callback);
    },
    getfaq:(data,callback)=>{

    let quey = "SELECT * FROM `faq` where sku_id in (" +data +")"
        
        return db.query(quey,callback);
    },
    upadteSKUImages : (data,callback)=>{
        let query = `UPDATE product_sku_images SET sku_image='${data.sku_db_path}' WHERE id=${data.id}`;
        return db.query(query,callback);
    }


};
module.exports = sku;