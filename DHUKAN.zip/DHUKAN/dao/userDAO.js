var db = require('../config/dbconnection'); //reference of dbconnection.js
const common = require('../common');
var Users = {
//All users list
    getAllUsers: function (callback) {
        return db.query("SELECT `u_id`, `first_name`, `last_name`, `email`, `phone`,landline_number,dob,  `user_status`, `location`, `latitude`, `longitude`, `image`, `business_name`, `created_on`, `updated_on`, `login_type`, `auth_key`, `refered_by`, `role`, `referral_code`, `is_used_referal` FROM `users`", callback);

    },
    getAllLocations :function(id,callback){
        return db.query("SELECT * FROM `locations` WHERE `country_id`=?", [id], callback);
    },
    getAllPincodes :function(id,callback){
        return db.query("SELECT * FROM `pincodes` WHERE `location_id`= ?", [id], callback);
    },
    findByEmail:function(email,callback){
        return db.query(`SELECT * FROM users WHERE email='${email}'`,callback);
    },
    findByPhoneNumber:function(data,callback){
        //console.log("phone number..",data.phone)
       return db.query(`select * from users where phone='${data.phone}'`,callback);
    },
    
    updatepassword:function(data,callback){
       return db.query("UPDATE users SET OTP='"+data.password+"' WHERE phone='"+data.phone+"'",callback) 
    },
    changePWD:function(data,callback){
        console.log("UPDATE users SET  password='"+data.password+"' WHERE phone='"+data.phone+"'")
        return db.query("UPDATE users SET password='"+data.password+"' WHERE phone='"+data.phone+"'",callback) 

    },
    //Get user details based on user id
    getUserById: function (id, callback) {
        return db.query("SELECT `u_id`, `first_name`, `last_name`, `email`, `phone`,landline_number,dob,  `user_status`, `location`, `latitude`, `longitude`, `image`, `business_name`, `created_on`, `updated_on`, `login_type`, `auth_key`, `refered_by`, `role`, `referral_code`, `is_used_referal` FROM `users` where u_id=?", [id], callback);
    }, 
    validate_user: function (email, phone, callback) {   //check user with phone number or email

        return db.query("SELECT `u_id`, `first_name`, `last_name`, `email`, `phone`,landline_number,dob,  `user_status`, `location`, `latitude`, `longitude`, `image`, `business_name`, `created_on`, `updated_on`, `login_type`, `auth_key`, `refered_by`, `role`, `referral_code`, `is_used_referal` FROM `users` where email=? or phone=?", [email, phone], callback);
    }, 
    validate_user_login: function (phone,  callback) {
        return db.query("SELECT * FROM `users` where  phone=? and status=1 limit 1", [phone], callback);
    },
    upadate_cart: function (session_id, user_id, callback) {
            // return db.query("update users set login_type=?,first_name=?,last_name=?,email=?,phone=? where u_id=?",
        //  [users_data.login_type,users_data.first_name,users_data.last_name,users_data.email,users_data.phone,id], callback);
        return db.query ("UPDATE `cart_orders` SET `user_id` = ? WHERE `cart_orders`.`session_id` = ?",[user_id, session_id], callback)
        // return db.query("SELECT * FROM `users` where  phone=? and status=1 limit 1", [phone], callback);
    },
    validate_solial_login: function (auth_key, callback) {
        return db.query("SELECT * FROM `users` where  auth_key=? and status=1 limit 1", [auth_key], callback);
    },
    verifyReferelcode: function (ref_code, callback) {
        var result = db.query("SELECT * FROM `users` where referral_code=" + ref_code, callback);
        return result;
    },
    country:function(callback){
     return  db.query("SELECT * FROM `country`",callback)
    },
    checkemailid:function(data,callback){
        console.log(data.email)
         console.log("SELECT * FROM `users` where email='"+data.email+"'")
        return  db.query("SELECT * FROM `users` where email='"+data.email+"'",callback)
    },
    admincreation:function(data,callback){
         //console.log("INSERT INTO users(first_name,last_name,email,phone,password,role) VALUES('"+data.first_name+"','"+data.last_name+"','"+data.email+"',"+data.phone+",'"+data.password+"','"+data.type+"')")
      return db.query("INSERT INTO users(first_name,last_name,email,phone,password,role) VALUES('"+data.first_name+"','"+data.last_name+"','"+data.email+"',"+data.phone+",'"+data.password+"','"+data.type+"')",callback)
    },
    loginuser:function(data,callback){
         console.log("SELECT * FROM `users` where email='"+data.email+"' AND password='"+data.password+"'")
        return  db.query("SELECT * FROM `users` where email='"+data.email+"' AND password='"+data.password+"'",callback)

    },
    addUser: function (users_data, callback) {
/*
        var user_input = {
            first_name: users_data.first_name,
            last_name: users_data.last_name,
            email: users_data.email,
            phone: users_data.phone,
            password: users_data.password,
            user_status: 1,
            latitude: '',
            longitude: '',
            image: '',
            business_name: '',
            created_on: users_data.created_on,
            updated_on: '',
            login_type: 'DHUKAHAN',
            auth_key: '',
            refered_by: '',
            role: 'USER',
            referral_code: '',
            is_used_referal: 'No',
            status: 1
        };

        */
       var user_input = {
        first_name: (!users_data.first_name) ? "" :users_data.first_name,
        last_name: (!users_data.last_name) ? "" :users_data.last_name,
        email: (!users_data.email) ? "" :users_data.email ,
        phone: (!users_data.phone)? "" :users_data.phone ,
        password: (!users_data.password) ? "" : users_data.password,
        user_status: 1,
        latitude: (!users_data.latitude) ? "" : users_data.latitude,
        longitude:(!users_data.longitude) ? "" : users_data.longitude,
        image: '',
        business_name: '',
        created_on: (!users_data.created_on) ? "" : users_data.created_on,
        updated_on: '',
        login_type:(!users_data.login_type) ? "" :users_data.login_type,
        auth_key: (!users_data.auth_key)? "" : users_data.auth_key,
        refered_by: (!users_data.refered_by)? "" : users_data.refered_by,
        role: 'USER',
        referral_code: (!users_data.referral_code)? "" : users_data.referral_code,
        is_used_referal: (!users_data.referral_code) ? "" : users_data.referral_code,
        status: 1
    };
        var result_data = db.query("INSERT INTO users SET ?", user_input, callback);
        return result_data;
    },
    deleteUser: function (id, callback) {
        return db.query("delete from users where u_id=?", [id], callback);
    },
    updateUser: function (id,users_data, callback) { 
        return db.query("update users set login_type=?,first_name=?,last_name=?,email=?,phone=? where u_id=?",
         [users_data.login_type,users_data.first_name,users_data.last_name,users_data.email,users_data.phone,id], callback);
    },
    uploadProfileData: function(user_data, callback){
        var usersFields = {
            first_name:user_data.first_name,
            last_name:user_data.last_name,
            phone:user_data.phone,
            email:user_data.email,
            updated_on:'now()'
        };

        if(common.checkKeyInObj(user_data.dob)){usersFields.dob = user_data.dob;}
        if(common.checkKeyInObj(user_data.landline_number)){usersFields.landline_number = user_data.landline_number;}

        var whereConditions = {u_id:user_data.user_id};
        var query = common.formUpdateQuery({table_name:'users',fields:usersFields,type:'update',whereConditions:whereConditions});
        return db.query(query, callback);
    },
    getTermasAndConditions:function(callback){
        return db.query("SELECT * FROM `terms_and_conditions`", callback);

    },
    faq:function(callback){
        return db.query("SELECT * FROM `faq`", callback);
  
    },
    getreturnrepolicy:(callback)=>{
        return db.query("SELECT * FROM `return _repolicy`",callback)

   },
   ckecKOTP:(user,callback)=>{
    return db.query(`SELECT * FROM users WHERE OTP=${user.otp} AND (phone=${user.phone} OR email='${user.email}')`,callback)
   }


};
module.exports = Users;