var db = require('../config/dbconnection');
var oders={
    getoders:function(callback){
      return db.query("select * from orders",callback)  
    },
    savedelevaryboyadress:function(data,role,cb){
        //console.log(role)
         //console.log("insert into users(first_name,email,image,password,phone,role) VALUES('"+data.name+"','"+data.email+"','"+data.image_path+"','"+data.password+"',"+data.phone+",'"+role+"')")
        return db.query("insert into users(first_name,email,image,password,phone,role) VALUES('"+data.name+"','"+data.email+"','"+data.image_path+"','"+data.password+"',"+data.phone+",'"+role+"')",cb)
    },
    getdelovoryadress:function(callback){
         //console.log("SELECT * FROM `users` where role='delevaryboy'")
        return db.query("SELECT * FROM `users` where role='delevaryboy'",callback)
    },
    deltedelvoty:function(data,callback){
        return db.query("delete from `users` where u_id="+data.id+"",callback)
    },
    getdatabyid:function(data,callback){
        return db.query("select * from users where u_id="+data.id+"",callback)
    },
    updateoders:function(data,callback){
         console.log(data)
        if(data.image_path!==""){
            console.log("hii")
            return db.query ("UPDATE users SET first_name ='"+data.first_name+"',image='"+data.image_path+"',email='"+data.email+"',password='"+data.password+"',phone="+data.phone+" WHERE u_id="+data.id+" ",callback);
        }else{
            return db.query ("UPDATE users SET first_name ='"+data.first_name+"',email='"+data.email+"',password='"+data.password+"',phone="+data.phone+" WHERE u_id="+data.id+" ",callback);
        }

    }

}
 module.exports=oders