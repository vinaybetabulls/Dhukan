//reference of dbconnection.js
var db = require('../config/dbconnection'); 
const common = require('../common');

var checkSessionAndUserId = function(obj){
    let user_id = obj.user_id;
    let session_id = obj.session_id;
    let userCond = "";var sessionCondi = "";
    if(user_id != ''){
        userCond = " user_id = '"+user_id+"' ";
    }
    if(session_id != ''){
        if(userCond != ''){
            sessionCondi += " or ";
        }
        sessionCondi += " session_id = '"+session_id+"' ";
    }
    return ' (' + userCond + sessionCondi +' )';
}

var cartOrders = {
    //All cart list by user id
    getCartlistByUserSessionId:function(user_id,session_id,callback){
        var obj = {user_id:user_id,session_id:session_id}
        var que = "SELECT * FROM cart_orders WHERE " + checkSessionAndUserId(obj) ;
        return db.query(que,callback);
    },
    getCartItemsByUserId: function (user_id,callback) {
        return db.query("SELECT co.id, co.user_id, co.session_id, co.product_id, co.quantity, co.created_on,co.product_sku_id, p.title,p.description,p.actual_price,p.offer_price,p.product_image,p.thumb_image1,p.thumb_image2,p.sku,co.product_sku_id FROM cart_orders co left join products p on p.id = co.product_id WHERE co.user_id = ? or co.session_id = ? ",[user_id,user_id], callback);
    },
    getCartItemsByUserIdSessionId: function (user_id,session_id,callback) {
        return db.query("SELECT co.id, co.user_id, co.session_id, co.product_id, co.quantity, co.created_on,co.product_sku_id, p.title,p.description,p.actual_price,p.offer_price,p.product_image,p.thumb_image1,p.thumb_image2,p.sku,co.product_sku_id FROM cart_orders co left join products p on p.id = co.product_id WHERE co.user_id = ? or co.session_id = ? ",[user_id,session_id], callback);
    },
    deleteCartItemsByUserId:function(user_id,callback){
        return db.query("delete from cart_orders where user_id= '"+user_id+"' or session_id= '"+user_id+"' ", callback);
    },
    clearMyCartItemByProduct:function(user_id,obj,callback){
        return db.query("delete from cart_orders where (user_id= '"+user_id+"' or session_id= '"+user_id+"') and id = '"+obj.cart_id+"' ", callback);
    },
    addMyCartItems:function(user_id,session_id,user_data,callback){
        var cartFields = {
            user_id:user_id,
            session_id:session_id,
            product_id:user_data.product_id,
            quantity:user_data.quantity,
            product_sku_id:user_data.product_sku_id,
            created_on:'now()'
        };
        var query = common.formInsertQuery({table_name:'cart_orders',fields:cartFields,type:'insert'});
        return db.query(query, callback);
    },
    updateMyCartItems:function(user_id,session_id,user_data,callback){
        var cartFields = {
            user_id:user_id,
            session_id:session_id,
            product_id:user_data.product_id,
            quantity:user_data.quantity,
            product_sku_id:user_data.product_sku_id
        };
        var query = "update cart_orders set quantity = '"+cartFields.quantity+"' where product_id = '"+cartFields.product_id+"' and ";
        query += " (user_id = '"+cartFields.user_id+"' or session_id = '"+cartFields.session_id+"' ) ";
        query += " and product_sku_id = '"+cartFields.product_sku_id+"' ";
        return db.query(query, callback);
    },
    checkMyCartItems:function(user_id,session_id,user_data,callback){
        var fields = {
            user_id:user_id,
            session_id:session_id,
            product_id:user_data.product_id,
            product_sku_id:user_data.product_sku_id
        };
        var query = "select * from cart_orders where product_sku_id = '"+fields.product_sku_id+"' and  product_id = '"+fields.product_id+"' and (session_id = '"+fields.session_id+"' or user_id = '"+fields.user_id+"' ) ";
        return db.query(query, callback);
    },
    updateSessionToUser:function(u_id,session_id,callback){
        var que = "update cart_orders set user_id = '"+u_id+"' where session_id = '"+session_id+"' ";
        return db.query(query, callback);
    }
};

module.exports = cartOrders;