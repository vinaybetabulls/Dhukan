var db = require('../config/dbconnection'); 

var refund = {
    getRefundOrderDetails :  (order_id,callback)=>{
        return db.query(`SELECT * FROM orders WHERE order_id=${order_id}`,callback);
    },
    refundProductDetails : (order_id,policy_id,amount,callback)=>{
        return db.query(`UPDATE orders SET refundpolicy='${policy_id}', refundamount=${amount}, refund_status='${"proccessing"}' WHERE order_id=${order_id}`,callback)
    },
    getdata:(cb)=>{
         //console.log("hello")
         //console.log("select * from refund_policy")
        // return db.query("SELECT * FROM refund_policy",callback)
        return db.query("SELECT * FROM `refund_policy`",cb)
    }
}

module.exports = refund;
