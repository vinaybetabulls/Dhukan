//reference of dbconnection.js
var db = require('../config/dbconnection'); 
const common = require('../common');

var checkSessionAndUserId = function(obj){
    let user_id = obj.user_id;
    let session_id = obj.session_id;
    let userCond = "";var sessionCondi = "";
    if(user_id != ''){
        userCond = " user_id = '"+user_id+"' ";
    }
    if(session_id != ''){
        if(userCond != ''){
            sessionCondi += " or ";
        }
        sessionCondi += " session_id = '"+session_id+"' ";
    }
    return ' (' + userCond + sessionCondi +' )';
}

var cartOrders = {
    //All cart list by user id
    getCartlistByUserSessionId:function(user_id,session_id,callback){
        var obj = {user_id:user_id,session_id:session_id}
        var que = "SELECT * FROM cart_orders WHERE " + checkSessionAndUserId(obj) ;
        return db.query(que,callback);
    },
    getCartItemsByUserId: function (user_id,callback) {
        return db.query("SELECT co.id, co.user_id, co.session_id, co.product_id, co.quantity, co.created_on,co.product_sku_id, p.title,p.thumb_image1,p.thumb_image2,co.product_sku_id FROM cart_orders co left join products p on p.id = co.product_id WHERE co.user_id = ? ",[user_id], callback);
    },
    getCartItemsByUserIdSessionId: function (user_id,session_id,callback) {
        //if(user_id){
            //return db.query("SELECT co.id, co.user_id, co.session_id, co.product_id, co.quantity, co.created_on,co.product_sku_id, p.title,p.description,p.actual_price,p.offer_price,p.product_image,p.thumb_image1,p.thumb_image2,p.sku,co.product_sku_id FROM cart_orders co left join products p on p.id = co.product_id WHERE co.user_id = ? ",[user_id], callback);
  
        //}
       // else{
           console.log("user_id",user_id)
           if(user_id==''){
               user_id=-1; 
           }
        return db.query("SELECT co.id, co.user_id, co.session_id, co.product_id, co.quantity, co.created_on,co.product_sku_id, p.title,p.thumb_image1,p.thumb_image2,co.product_sku_id FROM cart_orders co left join products p on p.id = co.product_id WHERE co.user_id = ? or co.session_id = ? ",[user_id,session_id], callback);
    //}
},
    deleteCartItemsByUserId:function(user_id,session_id,callback){
        console.log(user_id,session_id)
        return db.query("delete from cart_orders where user_id= '"+user_id+"' or session_id= '"+session_id+"' ", callback);
    },
    clearMyCartItemByProduct:function(user_id,session_id,obj,callback){
        //console.log(obj.product_id)
        return db.query("delete from `cart_orders` where (user_id= '"+user_id+"' OR session_id='"+session_id+"')AND product_sku_id= "+obj.product_id+"", callback);
        //return db.query("delete from `cart_orders` where (user_id= "+user_id+" AND product_sku_id= "+obj.product_id+") OR (session_id='"+session_id+"' AND product_sku_id= "+obj.product_id+")", callback);
    },
    addMyCartItems:function(user_id,session_id,user_data,callback){
        var cartFields = {
            user_id:user_id,
            session_id:session_id,
            product_id:user_data.product_id,
            quantity:user_data.quantity,
            product_sku_id:user_data.product_sku_id,
            created_on:'now()'
        };
        var query = common.formInsertQuery({table_name:'cart_orders',fields:cartFields,type:'insert'});
        return db.query(query, callback);
    },
    updateMyCartItems:function(user_id,session_id,user_data,callback){
         
        var cartFields = {
            user_id:user_id,
            session_id:session_id,
            product_id:user_data.product_id,
            quantity:user_data.quantity,
            product_sku_id:user_data.product_sku_id
        };
        var query = "update cart_orders set quantity = '"+cartFields.quantity+"' where product_id = '"+cartFields.product_id+"' and ";
        query += " (user_id = '"+cartFields.user_id+"' or session_id = '"+cartFields.session_id+"' ) ";
        query += " and product_sku_id = '"+cartFields.product_sku_id+"' ";
        return db.query(query, callback);
    },
    checkMyCartItems:function(user_id,session_id,user_data,callback){
        if(user_id==''){
            user_id=-1; 
        }
        var fields = {
            user_id:user_id,
            session_id:session_id,
            product_id:user_data.product_id,
            product_sku_id:user_data.product_sku_id
        };
      
        var query = "select * from cart_orders where product_sku_id = '"+fields.product_sku_id+"' and  product_id = '"+fields.product_id+"' and (session_id = '"+fields.session_id+"' or user_id = '"+fields.user_id+"' ) ";
         console.log("user_id:" +query);
        return db.query(query, callback);
    },
    updateSessionToUser:function(u_id,session_id,callback){
        var que = "update cart_orders set user_id = '"+u_id+"' where session_id = '"+session_id+"' ";
        return db.query(query, callback);
    },
    wishlistinsert:function(data,callback){
         //console.log("INSERT INTO wish_list (user_id,session_id,product_id,quantity,product_sku_id)VALUES(" + data.user_id + "," + data.session_id + ","+data.product_id+","+data.quantity+","+data.product_sku_id+")")
    return db.query("INSERT INTO wish_list (user_id,session_id,product_id,quantity,product_sku_id)VALUES(" + data.user_id + "," + data.session_id + ","+data.product_id+","+data.quantity+","+data.product_sku_id+")", callback)

    },
    getwishlist:(userId,sessionId,callback)=>{
        return db.query(`select * from wish_list where (session_id='${sessionId}' OR user_id='${userId}')`,callback)
    },
    deleteWishListByuserId:(userId,sessionId,callback)=>{
        return db.query(`DELETE FROM wish_list WHERE (user_id='${userId}' OR session_id = '${sessionId}' )`,callback)
    },
    deleteWishListId : (wishlistId,callback)=>{
        return db.query(`DELETE FROm wish-list WHERE id='${wishlistId}'`,callback)
    },
    saveOrder:(cart,callback)=>{
        return db.query(`INSERT INTO orders (order_id,delivery_charges,delivery_type)`)
    }
   
};

module.exports = cartOrders;    