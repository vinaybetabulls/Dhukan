//reference of dbconnection.js
var db = require('../config/dbconnection'); 
var productSpecifications = {
    getProductSpecificationsByProductId: function (product_id,callback) {
        return db.query("SELECT id, product_id, specification, value, status FROM product_specification where product_id in ("+product_id+")", callback);
    }
};
module.exports = productSpecifications;